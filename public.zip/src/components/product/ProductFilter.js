import React, { useState } from 'react';
import '../../styles/ProductFilter.css'; 

const ProductFilter = ({ onFilterChange }) => {
  const [category, setCategory] = useState('');
  const [sort, setSort] = useState('');

  const handleCategoryChange = (e) => {
    setCategory(e.target.value);
    onFilterChange({ category: e.target.value, sort });
  };

  const handleSortChange = (e) => {
    setSort(e.target.value);
    onFilterChange({ category, sort: e.target.value });
  };

  return (
    <div className="product-filter">
      <select value={category} onChange={handleCategoryChange}>
        <option value="">All Categories</option>
        <option value="electronics">Electronics</option>
        <option value="fashion">Fashion</option>
        <option value="home">Home & Furniture</option>
      </select>

      <select value={sort} onChange={handleSortChange}>
        <option value="">Sort By</option>
        <option value="price-low">Price: Low to High</option>
        <option value="price-high">Price: High to Low</option>
      </select>
    </div>
  );
};

export default ProductFilter;
