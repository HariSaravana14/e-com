import React from 'react';
import { star } from '../assets/icons'; 

const PopularProductCard = ({ imgURL, name, price, rating }) => {
  return (
    <div className="flex flex-col items-center w-full max-sm:w-full">
      <img src={imgURL} alt={name} className="w-[280px] h-[280px] object-cover rounded-lg" />
      <div className="flex items-center gap-2.5 mt-2">
        <img src={star} alt="rating" width={24} height={24} />
        <p className="font-montserrat text-xl text-gray-600">{rating}</p>
      </div>
      <h3 className="mt-2 text-2xl font-semibold font-palanquin text-gray-900">{name}</h3>
      <p className="mt-1 font-semibold font-montserrat text-coral-red text-2xl">{price}</p>
    </div>
  );
};

export default PopularProductCard;
