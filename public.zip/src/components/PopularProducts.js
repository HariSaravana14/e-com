import React from 'react';
import PopularProductCard from './PopularProductCard';

const popularProducts = [
  {
    id: 1,
    name: "Nike Air Zoom",
    price: "$120",
    rating: "4.5",
    imgURL: "/images/shoe1.jpeg",
  },
  {
    id: 2,
    name: "Adidas Ultraboost",
    price: "$140",
    rating: "4.6",
    imgURL: "/images/shoe2.jpg",
  },
  {
    id: 3,
    name: "Puma RS-X",
    price: "$110",
    rating: "4.4",
    imgURL: "/images/shoe3.jpg",
  },
  {
    id: 4,
    name: "Reebok Zig Kinetica",
    price: "$130",
    rating: "4.7",
    imgURL: "/images/shoe4.jpg",
  },
];

const PopularProducts = () => {
  return (
    <section className="py-10 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center text-gray-900">Popular Products</h2>
        <p className="text-center text-lg text-gray-500 mt-2">
          Discover our trending shoes with top ratings.
        </p>

        <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {popularProducts.map((product) => (
            <PopularProductCard key={product.id} {...product} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default PopularProducts;
