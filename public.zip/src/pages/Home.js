import React, { useEffect, useRef } from "react";
import "../styles/Home.css";
import shoeImage from "../assets/images/Home-shoe.png";

const Home = () => {
  const shoeImgRef = useRef(null);
  const textRef = useRef(null);

  useEffect(() => {
    shoeImgRef.current.classList.add("bounceIn");
    textRef.current.style.opacity = "1";
    textRef.current.style.transform = "translateY(0)";
  }, []);

  return (
    <div className="home-container">
      {/* Shoe Image & Content */}
      <div className="shoe-container">
        <div className="shoe-card">
          <img 
            src={shoeImage} 
            alt="Stylish Sneakers" 
            className="shoe-img"
            ref={shoeImgRef}
          />
        </div>
        <div className="text-container" ref={textRef}>
          <h2>Next-Gen Sneakers</h2>
          <p>
            Experience the future of footwear with our latest collection. 
            Designed for performance, comfort, and style.
          </p>
          <button className="shop-button">Shop Now</button>
        </div>
      </div>
    </div>
  );
};

export default Home;
