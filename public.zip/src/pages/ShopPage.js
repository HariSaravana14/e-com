// import React, { useState, useEffect } from "react";
// import { Swiper, SwiperSlide } from "swiper/react";
// import { Navigation, Pagination, Autoplay } from "swiper/modules";
// import "swiper/css";
// import "swiper/css/navigation";
// import "swiper/css/pagination";

// // Import images

// const trendingShoes = [
//   { id: 1, name: "Nike Air Zoom", price: "$120", image: "/assets/shoe1.jpeg" },
//   { id: 2, name: "Adidas Ultraboost", price: "$140", image: "/assets/shoe2.jpg" },
//   { id: 3, name: "Puma RS-X", price: "$110", image: "/assets/shoe3.jpg" },
//   { id: 4, name: "Reebok Zig Kinetica", price: "$130", image: "/assets/shoe4.jpg" },
// ];

// const ShoeStore = () => {
//   const [showCards, setShowCards] = useState(false);

//   useEffect(() => {
//     const handleScroll = () => {
//       if (window.scrollY > 500) {
//         setShowCards(true);
//       }
//     };
//     window.addEventListener("scroll", handleScroll);
//     return () => window.removeEventListener("scroll", handleScroll);
//   }, []);

//   return (
//     <div className="w-full min-h-screen bg-gray-100">
//       {/* Full-Screen Carousel */}
//       <div className="relative w-full h-screen">
//         <Swiper
//           modules={[Navigation, Pagination, Autoplay]}
//           navigation
//           pagination={{ clickable: true }}
//           autoplay={{ delay: 3000 }}
//           loop
//           className="w-full h-full"
//         >
//           {trendingShoes.map((shoe) => (
//             <SwiperSlide key={shoe.id}>
//               <div className="flex items-center justify-center h-screen bg-gradient-to-r from-purple-500 to-pink-500">
//                 <img
//                   src={shoe.image}
//                   alt={shoe.name}
//                   className="w-3/4 md:w-1/2 drop-shadow-xl"
//                 />
//               </div>
//             </SwiperSlide>
//           ))}
//         </Swiper>
//       </div>

//       {/* Trending Shoes (Cards Appear on Scroll) */}
//       <div className="p-10 text-center">
//         <h2 className="text-3xl font-bold text-gray-800">🔥 Trending Shoes</h2>
//         <p className="text-gray-600">Discover the hottest picks right now!</p>

//         <div
//           className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-10 transition-all duration-700 ${
//             showCards ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"
//           }`}
//         >
//           {trendingShoes.map((shoe) => (
//             <div
//               key={shoe.id}
//               className="bg-white rounded-lg shadow-lg p-5 text-center hover:scale-105 transition"
//             >
//               <img src={shoe.image} alt={shoe.name} className="w-full h-40 object-cover mb-4" />
//               <h3 className="text-lg font-semibold">{shoe.name}</h3>
//               <p className="text-xl font-bold text-green-600">{shoe.price}</p>
//               <button className="mt-3 px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-700">
//                 Buy Now
//               </button>
//             </div>
//           ))}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default ShoeStore;
import React from 'react';
import PopularProducts from '../components/PopularProducts';

const ShopPage = () => {
  return (
    <div>
      <PopularProducts />
    </div>
  );
};

export default ShopPage;
