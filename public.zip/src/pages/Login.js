const Login = () => {
    return <h1 className="text-center text-2xl mt-10">Login to Your Account</h1>;
  };
  export default Login;
  