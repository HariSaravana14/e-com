const Cart = () => {
    return <h1 className="text-center text-2xl mt-10">Your Cart</h1>;
  };
  export default Cart;
  